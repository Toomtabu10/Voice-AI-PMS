# Lab Results → Source Document Link

## What this adds
Each lab result extracted from a PDF now stores `document_id` and the UI shows a clickable link to download/view that PDF.

## Files to overwrite
```
app/models.py
app/schemas.py
app/routers/documents.py
app/routers/patients.py
app/static/app.js
```

## Migration
```bash
# Easy – fresh DB
rm data/patient_records.db

# Or keep data
sqlite3 data/patient_records.db "ALTER TABLE lab_results ADD COLUMN document_id INTEGER REFERENCES documents(id);"
```

## Note
Only labs created **after** this update (from a new PDF upload) will have the link. Existing labs stay without a document_id.
